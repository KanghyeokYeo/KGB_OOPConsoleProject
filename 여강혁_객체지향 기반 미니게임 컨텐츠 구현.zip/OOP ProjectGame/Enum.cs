﻿namespace OOP_ProjectGame
{
    public enum BattleType { Title, Sellect, Punch, Hook, UpperCut, Size }
}
